import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { HostelDetailsComponent } from './hostel-details/hostel-details.component';
import { SignupComponent } from './signup/signup.component';
import { CriteriaComponent } from './criteria/criteria.component';
import { FacilitiesComponent } from './facilities/facilities.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [

{path:'home',component:HomeComponent},
{path:'registration',component:RegistrationComponent},
{path:'hosteldetails',component:HostelDetailsComponent},
{path:'signup',component:SignupComponent},
{path:'criteria',component:CriteriaComponent},
{path:'facilities',component:FacilitiesComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
