import { Component } from '@angular/core';

@Component({
  selector: 'app-hostel-details',
  templateUrl: './hostel-details.component.html',
  styleUrl: './hostel-details.component.css'
})
export class HostelDetailsComponent {

}
